public class MusicBaseDao extends BaseDao{

}
