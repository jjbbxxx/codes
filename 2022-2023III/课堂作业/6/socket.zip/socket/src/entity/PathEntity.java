package entity;

public class PathEntity {
    private  String path_name;private String path_id;
    public String getPath_id() {
        return path_id;
    }
    public void setPath_id(String path_id) {
        this.path_id = path_id;
    }
    public String getPath_name() {
        return path_name;
    }
    public void setPath_name(String path_name) {
        this.path_name = path_name;
    }
}
