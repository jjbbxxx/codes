package entity;

public class RecommenderEntity {
    private String recommender_name;private String recommender_id;
    public void setRecommender_id(String recommender_id) {
        this.recommender_id = recommender_id;
    }
    public String getRecommender_id() {
        return recommender_id;
    }
    public String getRecommender_name() {
        return recommender_name;
    }
    public void setRecommender_name(String recommender_name) {
        this.recommender_name = recommender_name;
    }
}

